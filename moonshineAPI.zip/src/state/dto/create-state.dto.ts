export class CreateStateDto {
    state_id: number;
    state_name: string;
    country_id: number;
  }
  