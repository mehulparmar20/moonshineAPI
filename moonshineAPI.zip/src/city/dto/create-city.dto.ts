export class CreateCityDto {

    city_id: number;
    country_id : number;
    state_id :number;
    city_name: string;

}
