export class CreateCountryDto {
    country_id: number;
    country_name: string;
}
